require('plugins')
require('base')
require('maps')
require('highlights')

vim.cmd [[ colorscheme iceberg ]]
