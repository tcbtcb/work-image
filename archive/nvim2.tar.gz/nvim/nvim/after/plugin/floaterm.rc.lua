local status, float = pcall(require, 'floaterm')
