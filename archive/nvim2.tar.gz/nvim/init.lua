require('plugins')

vim.cmd [[ colorscheme iceberg ]]

