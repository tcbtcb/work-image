return {
    "tpope/vim-sleuth"
}
