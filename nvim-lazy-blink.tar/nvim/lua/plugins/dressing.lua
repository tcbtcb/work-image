return {
  'stevearc/dressing.nvim',
  opts = {},
}
