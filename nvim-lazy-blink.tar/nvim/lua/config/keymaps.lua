vim.keymap.set("n", "-", "<cmd>Oil --float<CR>", { desc = "open parent dir in oil" })

vim.keymap.set("n", "gl", function()
	vim.diagnostic.open_float()
end, { desc = "Open diagnostics in float win" })

vim.keymap.set("n", "<leader>cf", function()
	require("conform").format({
		lsp_format = "fallback",
	})
end, { desc = "[c]ode [f]ormat called manually" })
