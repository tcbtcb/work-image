return {
	"tpope/vim-sleuth",
}
