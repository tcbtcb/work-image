return {
	{ "akinsho/toggleterm.nvim", version = "*", opts = { size = 120, direction = vertical } },
}
