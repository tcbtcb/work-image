return {
    "tpope/vim-fugitive"
    }
