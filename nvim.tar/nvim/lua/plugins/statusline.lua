return {

	{ 'echasnovski/mini.statusline', version = false, opts = {} },
}
